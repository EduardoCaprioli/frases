const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());

const frases = [
  { quoteText: "Quem olha para fora sonha, quem olha para dentro desperta.", quoteAuthor: "Carl Jung" },
  { quoteText: "Torna-te quem tu és.", quoteAuthor: "Friedrich Nietzsche" },
  { quoteText: "A vida não examinada não vale a pena ser vivida.", quoteAuthor: "Sócrates" },
  { quoteText: "A dor é inevitável. O sofrimento é opcional.", quoteAuthor: "Haruki Murakami" },
  { quoteText: "A mente é tudo. O que você pensa, você se torna.", quoteAuthor: "Buda" }
];

app.get('/', (req, res) => {
  const random = Math.floor(Math.random() * frases.length);
  res.json(frases[random]);
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Servidor rodando na porta ${port}`);
});